
public class Thread_Synchronization_Mechanisms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
